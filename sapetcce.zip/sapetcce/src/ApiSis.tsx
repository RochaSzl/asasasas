// ApiSis.tsx

function ApiSis() {
    return (
        <>
            <div className="ChatBox">
                <p>Deseja usar qual funcionalidade do sistema?</p>
            </div>

            <div className="ChatBox">
                <p>Estamos trabalhando para adicionar mais funções. <br /> No momento, só temos essas disponíveis! :) </p>
            </div>




        </>
    );
}

export default ApiSis();  // Certifique-se de que o componente está sendo exportado como padrão
