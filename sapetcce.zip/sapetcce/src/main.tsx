import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import Login from "./Login";
import Register from "./Register";
import Index from "./Index";
import Config from "./Config";
import AboutSape from "./AboutSape";
import ApiSis from "./ApiSis";



import { createBrowserRouter, RouterProvider } from "react-router-dom";
const router = createBrowserRouter([
  {
    path: "/",
    element: <Login />,
  },
  {
    path: "/register",
    element: <Register />,
  },
  {
    path: "/index",
    element: <Index />,
  },
  {
    path: "/config",
    element: <Config />,
  },
  {
    path: "/apiSis",
    element: <ApiSis />,
  },

  {
    path: "/aboutSape",
    element: <AboutSape />,
  },

]);


ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <RouterProvider router={router} />
  </React.StrictMode>
);
