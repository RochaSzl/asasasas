import Sapezin from "./assets/sapezin.png";

import HomeIcon from "./assets/IconIndex.png";
function AboutSape() {
    const goToPage = (page) => {
        // Função para redirecionar para diferentes páginas
        window.location.href = page;
    };
    return (

        <>
            <div className="PictureSape">
                <div className="BubblePicture">
                    <img src={Sapezin} className="ImgSape" />
                </div>
            </div>
            <p>➔ O sape é um projeto estudantil feito para atender estudantes com necessidades específicas.</p>
            <p>Têm como princípios:</p>

            <li>Acessibilidade digital</li>
            <li>Inclusão no ensino</li>
            <li>Melhoria no aprendizado</li>

            <p>➔ Conquistamos o 2º lugar da Olimpíada de Inovação do IFRJ, a INOVAIFRJ</p>
            <p>➔ Em Outubro de 2023, fomos convidados a participar da RIO INNOVATION WEEK, o maior evento de inovação da América Latina.</p>
            <p>➔ Em 2024, participamos da World Creativity Day, um evento de inovação patrocinado pela ONU </p>
            <p>➔ Agora, estamos saindo do campo teórico e fazendo, como Trabalho de Conclusão de Curso, o SAPE.</p>

            <p>É o SAPE: um projeto de alunos, feito para alunos ! :)</p>

            <footer>

                <div className="BubbleHome" onClick={() => goToPage("/Index")}>
                    <img src={HomeIcon} className="ImgFooter" />
                </div>
            </footer>

        </>
    )


}
export default AboutSape;