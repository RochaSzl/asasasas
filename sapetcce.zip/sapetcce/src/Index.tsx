import "./App.css";
import HomeIcon from "./assets/IconIndex.png";
import ConfigIcon from "./assets/ConfigIcon.png";
import ApiIcon from "./assets/ApiIcon.png";
import AboutIcon from "./assets/AboutIcon.png";
import UserIcon from "./assets/UserIcon.png";


function Login() {
    const goToPage = (page) => {
        // Função para redirecionar para diferentes páginas
        window.location.href = page;
    };

    return (<>
        <header>
            <p className="TextInitial">Olá! <br /> Seja bem-vindo ao SAPE!</p>
            <div className="BubbleHeader">
                <img src={HomeIcon} className="ImgHeader" />
            </div>
        </header>

        <div className="ChatBox">
            <p>Com o que podemos ajudar?</p>
        </div>

        <div className="OptionsChatBox">
            <button className="optionButton" onClick={() => goToPage("/ApiSis")}>
                <img src={ApiIcon} className="ImgChatBox" />
                Ir para as aplicações do sistema
            </button>
            <button className="optionButton" onClick={() => goToPage("/Config")}>
                <img src={ConfigIcon} className="ImgChatBox" />
                Ir para Configurações
            </button>
            <button className="optionButton" onClick={() => goToPage("/AboutSape")}>
                <img src={AboutIcon} className="ImgChatBox" />
                Ir para Sobre o SAPE
            </button>
        </div>

        <footer>
            <div className="BubbleaApi" onClick={() => goToPage("/ApiSis")}>
                <img src={ApiIcon} className="ImgFooter" />
            </div>
            <div className="BubbleaAcessibility">
                <img src={UserIcon} className="ImgFooter" />
            </div>
            <div className="BubbleUser">
                <img src={UserIcon} className="ImgFooter" />
            </div>
        </footer>
    </>
    );
}

export default Login;
